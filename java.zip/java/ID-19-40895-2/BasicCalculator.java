
public class BasicCalculator implements Calculation {
	double value1;
	double value2;
	BasicCalculator( ){
		value1= 7;
		value2= 8;
	
		System.out.println("The two default value is set to  :"+value1+"and"+value2);
	}
	BasicCalculator(double v1, double v2){
		value1=v1;
		value2=v2;
		System.out.println("The values initiated from child class");
	}
	void setValue1(double v1) {
		value1=v1;
	}
	void setValue2(double v2) {
		value2=v2;
	}
	double getValue1( ) {
		return value1;
	}
	double getValue2( ) {
		return value2;
	}
	public double add( ) {
		double sum= value1+value2;
		return sum;
	}
	public double subtract( ) {
		double sub= value1-value2;
		return sub;
	}
	public double multiply( ) {
		double mul=value1*value2;
		return mul;
	}
	public double divide( ) {
		double div=value1/value2;
		return div;
	}
}
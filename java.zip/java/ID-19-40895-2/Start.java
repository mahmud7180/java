public class Start {

	public static void main(String[] args) {
		ScientificCalculator obj1= new ScientificCalculator();
		ScientificCalculator obj2= new ScientificCalculator(15,6);
		System.out.println("The Add 1st :"+obj1.add());
		System.out.println("The subtraction 1st  :"+obj1.subtract());
		System.out.println("The division 1st  :"+obj1.divide());
		System.out.println("The multiplication 1st :"+obj1.multiply());
		System.out.println("The value of the 1st"+obj1.tothePow());
		
		
		System.out.println("The summation of the 2nd :"+obj2.add());
		System.out.println("The subtraction of the 2nd :"+obj2.subtract());
		System.out.println("The division of the 2nd :"+obj2.divide());
		System.out.println("The multiplication of the 2nd :"+obj2.multiply());
		System.out.println("The value of the first number :"+obj2.tothePow());

	}

}
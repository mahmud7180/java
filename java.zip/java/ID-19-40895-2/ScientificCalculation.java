public interface ScientificCalculation {
	double tothePow();

}
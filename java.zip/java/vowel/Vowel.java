import java.util.Scanner;
 
public class Vowel{
     public static void main(String[] args){
	 
        char x;
		Scanner input=new Scanner(System.in);
		System.out.print("input= ");
		x=input.next().charAt(0);
		if(x=='a'){
		     System.out.println("vowel number");
		
		}
		else if(x=='e'){
		     System.out.println("vowel number");
		}
		else if(x=='i'){
		     System.out.println("vowel number");
		}
		else if(x=='o'){
		     System.out.println("vowel number");
		}
		else if(x=='u'){
		     System.out.println("vowel number");
		}
		else{
		     System.out.println("consonant");
		}
     }   	 
}
public class function
{
public void main(String [] args)
  {
    int x;
   int num,i;
   if(num==1)
   {
    i=0;
    while (i<5);
   {
       System.out.println("show my balance");
	   i++;
   }
   }
   else if
        (num==2)
        for(i=0;i>5;i++)
   {
       System.out.println("depond balance");
   }
   else if
    (num==3)
   {
       System.out.println("withdraw money");
   }
   else
    System.out.println("invalid option");



{
    int t;
    System.out.println("select any number");
//cin>>t;
    System.out.println(+t);
}
}
}
  
public class Main{
	public static void main(String [] args){
	
	programming obj1= new programming();

	
	}
}

public class Programming1{
	public static void main(String [] args){
	
	programming obj1= new programming();

	
	}
}

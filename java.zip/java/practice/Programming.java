public class Programming{
	
	
	programming(){
		System.out.println("i love programming languages");
	}
	
	 programming(String n){
	
		System.out.println("i love java" + n);
	}
	
	
		
}
}

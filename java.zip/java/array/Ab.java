public class Ab{
     public static void main(String [] args){
	 
	     int[] sequence = new int[5];
         for (int i=0; i< sequence.length; i++)
		 { 
		     sequence[i] = i * 25;
         }
        System.out.println(sequence[i]);
     }	 
}
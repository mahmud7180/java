public class B extends A{
    public int b;
	public B(){
	    System.out.println("inside B is  empty ");
	}
	
	public B(int b){
	    super(b);
		System.out.println("B is a constructor-vslued");
	}
	
}
public abstract class ScintificCalculation{
    
	public abstract double toThePow();
	
}
public class ScintificCalculation{
    
	public abstract double toThePow();
	
}
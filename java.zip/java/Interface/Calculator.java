public interface Calculator{
    double add();
	double subtract();
	double multiply();
	double divide();
}

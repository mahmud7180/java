public class Circle{
     double radius;
	 
	 public void Circle(){
	 
	 }
	 void setRadius(double radius){
	     this.radius=radius;
	 }
	 double getRadius(){
	     return radius;
	double getArea( ){
	     return radius*radius;
	}
}
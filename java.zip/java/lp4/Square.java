public class Square{
    double side;
	
	public void Square(){
	
	}
	
	void setSide(double side){
	    this.side=side;  
	}
	
	double getSide(){
	    return side;
	}
	 
	double getArea(){
	    return  (2*side);
	}
}
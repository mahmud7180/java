public class Triangle{
   double height;
   double base;
   
   Triangle(){
    setHight(10);
    setBase(4);
    getHight();
    getBase();
	getArea();
   }
   Triangle(double height,double base)
   {
     //void setHight(double hight);
	 //void setBase( double base);
	 System.out.println("hight :" + getHight());
	 System.out.println("base :" + getBase());
	 System.out.println("area :" + getArea());
   }
   void setHight(double h){
     Hight=h;
	 
	}

   void setBase(double b){
     Base=b;
    }
   double getHight( )
    {
      return Hight;
    }
    double getBase( )
    {
    return Base;
     }
    double getArea( )
    {
    return (0.5*(hight*base));
    }
	/*public static void main(String[] args)
	{
		Triangle obj2= new Triangle();
	}*/
 }

   
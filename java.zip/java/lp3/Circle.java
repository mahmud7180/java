public class Circle
{


double radius;

double a;

public void setradius(double r)
{
radius=r;
}
public double getradius()
{
return radius;
}
public void getArea()
{
a=3.1416*radius*radius;
System.out.println("The area of Circle:"+a);
}
}
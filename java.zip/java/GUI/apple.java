import javax.swing.JFrame;
public class apple {
	
	public static void main(String [] args) {
		
		tuna ankon=new tuna();
		ankon.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ankon.setSize(275,180);
		ankon.setVisible(true);
	}

}

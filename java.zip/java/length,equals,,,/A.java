 public class A{
    public static void main(String [] args){
	    
		String myString="i love java";
		String myString1="i love c++";
		String myString2="    i love c++"    ;
		
		System.out.println(myString.length());
		System.out.println(myString.charAt(0));
		System.out.println(myString.equals(myString1));
		System.out.println(myString.substring(2,6));
		System.out.println(myString.toUpperCase());
		System.out.println(myString1.toLowerCase());
		System.out.println(myString2.trim());//it is use for cut the initial & ending space
		
	}
 }
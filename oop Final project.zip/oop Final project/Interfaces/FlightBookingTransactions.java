package Interfaces;

import java.lang.*;

public interface FlightBookingTransactions
{
	boolean depositBalance(double amount);
	boolean withdrawBalance(double amount);
}
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Peach extends JPanel {

	public void painComponent(Graphicscg) {
		super.paintComponent(g);
		this.setBackground(Color.WHITRE);
		
		g.setColor(Color.BLUE);
		g.fillREct(25,25,100,30);
		
		g.setColor(new Color(290,81,215));
		g.dillRect(25,65,100,30);
		
		g.setColor(Color,RED);
		g.drawSrring("this is same tecxt",25,120);
	}
}


import javax.swing.*;

public class bucky{
    public static void main(String [] args){
	    Peach p=new Peach();
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}